window.LEXOR_MEDIA_ADMIN_CONFIG = {
  // Public config only. This file is safe to expose because it contains no password.
  // Username/password are checked by the Worker using Cloudflare environment variables.
  apiBase: 'https://lexor-media-gallery-api.lexortechdev.workers.dev',
  rememberLogin: true,
  appName: 'Lexor Media Gallery Admin'
};
