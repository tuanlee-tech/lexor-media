const state = {
  view: 'structure',
  refs: {
    categories: [],
    subCategories: [],
    folders: [],
    media: [],
  },
  filters: {
    category_id: '',
    sub_category_id: '',
    folder_id: '',
    media_type: '',
  },
  editing: {
    resource: '',
    id: '',
    context: {},
  },
};

const viewMeta = {
  structure: {
    title: 'Structure Builder',
    description:
      'Build the gallery tree like Shopify menu items. Drag rows to reorder.',
  },
  library: {
    title: 'Media Library',
    description:
      'A central library of all images, videos, YouTube links, and Shopify CDN URLs.',
  },
  settings: {
    title: 'Settings',
    description: 'Review login status and admin API connection.'
  },
};

const resourceMeta = {
  categories: { label: 'Category', path: '/api/admin/categories' },
  'sub-categories': {
    label: 'Sub Category',
    path: '/api/admin/sub-categories',
  },
  folders: { label: 'Folder', path: '/api/admin/folders' },
  media: { label: 'Media Item', path: '/api/admin/media' },
};

const els = {
  appShell: document.querySelector('.app-shell'),
  content: document.querySelector('#content'),
  viewTitle: document.querySelector('#viewTitle'),
  viewDescription: document.querySelector('#viewDescription'),
  notice: document.querySelector('#notice'),
  refreshBtn: document.querySelector('#refreshBtn'),
  newBtn: document.querySelector('#newBtn'),
  logoutBtn: document.querySelector('#logoutBtn'),
  dialog: document.querySelector('#editDialog'),
  editForm: document.querySelector('#editForm'),
  dialogTitle: document.querySelector('#dialogTitle'),
  dialogDescription: document.querySelector('#dialogDescription'),
  formFields: document.querySelector('#formFields'),
};

const adminConfig = {
  apiBase: '',
  rememberLogin: true,
  appName: 'Lexor Media Gallery Admin',
  ...(window.LEXOR_MEDIA_ADMIN_CONFIG || {}),
};

const storageKeys = {
  authToken: 'lexorMediaAdminToken',
  username: 'lexorMediaAdminUsername',
  remember: 'lexorMediaRememberLogin',
};

function normalizeApiBase(value) {
  return String(value || '').trim().replace(/\/$/, '');
}

function getApiBase() {
  return normalizeApiBase(adminConfig.apiBase || '');
}

function getStoredAuthToken() {
  return (
    sessionStorage.getItem(storageKeys.authToken) ||
    localStorage.getItem(storageKeys.authToken) ||
    ''
  );
}

function getSavedUsername() {
  return (
    localStorage.getItem(storageKeys.username) ||
    sessionStorage.getItem(storageKeys.username) ||
    ''
  );
}

function isRememberLoginEnabled() {
  return localStorage.getItem(storageKeys.remember) === '1';
}

function saveAdminSession({ token, username, remember = false }) {
  const nextToken = String(token || '');
  const nextUsername = String(username || '');
  if (!nextToken) return;

  if (remember) {
    localStorage.setItem(storageKeys.authToken, nextToken);
    localStorage.setItem(storageKeys.remember, '1');
    if (nextUsername) localStorage.setItem(storageKeys.username, nextUsername);
    sessionStorage.removeItem(storageKeys.authToken);
    sessionStorage.removeItem(storageKeys.username);
    return;
  }

  sessionStorage.setItem(storageKeys.authToken, nextToken);
  if (nextUsername) sessionStorage.setItem(storageKeys.username, nextUsername);
  localStorage.removeItem(storageKeys.authToken);
  localStorage.removeItem(storageKeys.username);
  localStorage.removeItem(storageKeys.remember);
}

function clearAdminAuth() {
  sessionStorage.removeItem(storageKeys.authToken);
  sessionStorage.removeItem(storageKeys.username);
  localStorage.removeItem(storageKeys.authToken);
  localStorage.removeItem(storageKeys.username);
  localStorage.removeItem(storageKeys.remember);
}

function getSettings() {
  return {
    apiBase: getApiBase(),
    authToken: getStoredAuthToken(),
    username: getSavedUsername(),
    remember: isRememberLoginEnabled(),
  };
}
function closeEditor() {
  if (!els.dialog?.open) return;
  els.dialog.close('cancel');
}

function bindDialogCloseControls() {
  document.querySelectorAll('[data-dialog-close]').forEach((button) => {
    button.addEventListener('click', closeEditor);
  });

  // Click on the native dialog backdrop to close without triggering form validation.
  els.dialog.addEventListener('click', (event) => {
    if (event.target !== els.dialog) return;
    closeEditor();
  });
}


function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function showNotice(message, isError = false) {
  els.notice.textContent = message;
  els.notice.classList.toggle('is-error', isError);
  els.notice.hidden = false;
  window.clearTimeout(showNotice.timer);
  showNotice.timer = window.setTimeout(() => {
    els.notice.hidden = true;
  }, 4200);
}

function updateNav() {
  document.querySelectorAll('.nav__item').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.view === state.view);
  });
}

function requireSettings() {
  const { apiBase, authToken } = getSettings();
  if (!apiBase) {
    renderConfigError();
    return false;
  }
  if (!authToken) {
    renderLogin();
    return false;
  }
  return true;
}

function authHeaders() {
  const { authToken } = getSettings();
  return authToken
    ? {
        Authorization: `Bearer ${authToken}`,
      }
    : {};
}

async function verifyLogin() {
  const { apiBase, authToken } = getSettings();
  if (!apiBase || !authToken) return false;
  try {
    const res = await fetch(`${apiBase}/api/admin/verify`, {
      headers: authHeaders(),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function loginWithCredentials(username, password, remember) {
  const apiBase = getApiBase();
  if (!apiBase) {
    throw new Error('Admin API URL is not configured.');
  }

  const res = await fetch(`${apiBase}/api/admin/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  });

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(data?.message || data?.error || 'Cannot login.');
  }

  saveAdminSession({ token: data.token, username: data.username || username, remember });
  return data;
}

async function api(path, options = {}) {
  const { apiBase } = getSettings();
  if (!apiBase) throw new Error('Admin API URL is not configured.');
  const res = await fetch(`${apiBase}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders(),
      ...(options.headers || {}),
    },
  });
  const data = await res.json().catch(() => null);
  if (!res.ok)
    throw new Error(
      data?.message || data?.error || `Request failed: ${res.status}`,
    );
  return data;
}

async function fetchAll(resource, query = '') {
  const items = [];
  let offset = 0;
  const limit = 200;
  while (true) {
    const sep = query ? '&' : '?';
    const data = await api(
      `${resourceMeta[resource].path}${query || '?'}${query ? sep : ''}limit=${limit}&offset=${offset}`,
    );
    const batch = data.items || [];
    items.push(...batch);
    if (batch.length < limit) break;
    offset += limit;
  }
  return items;
}

async function loadAll() {
  const [categories, subCategories, folders, media] = await Promise.all([
    fetchAll('categories'),
    fetchAll('sub-categories'),
    fetchAll('folders'),
    fetchAll('media'),
  ]);
  state.refs.categories = categories;
  state.refs.subCategories = subCategories;
  state.refs.folders = folders;
  state.refs.media = media;
}

function bySort(a, b) {
  return (
    Number(a.sort_order || 0) - Number(b.sort_order || 0) ||
    String(a.title || '').localeCompare(String(b.title || ''))
  );
}

function titleOf(list, id) {
  return list.find((item) => String(item.id) === String(id))?.title || '—';
}

function nextSort(items, field, value) {
  const scoped = field
    ? items.filter((item) => String(item[field] || '') === String(value || ''))
    : items;
  const max = scoped.reduce(
    (n, item) => Math.max(n, Number(item.sort_order || 0)),
    -10,
  );
  return max + 10;
}

function getSubOptions(categoryId) {
  return state.refs.subCategories
    .filter(
      (item) => !categoryId || String(item.category_id) === String(categoryId),
    )
    .sort(bySort);
}

function getFolderOptions(categoryId, subCategoryId) {
  return state.refs.folders
    .filter((item) => {
      if (categoryId && String(item.category_id) !== String(categoryId))
        return false;
      if (
        subCategoryId &&
        String(item.sub_category_id) !== String(subCategoryId)
      )
        return false;
      return true;
    })
    .sort(bySort);
}

async function loadView() {
  const meta = viewMeta[state.view];
  els.viewTitle.textContent = meta.title;
  els.viewDescription.textContent = meta.description;
  els.newBtn.hidden = state.view === 'settings';
  els.refreshBtn.hidden = state.view === 'settings';
  els.newBtn.textContent =
    state.view === 'library' ? 'New media item' : 'New category';

  if (state.view === 'settings') {
    renderSettings();
    return;
  }

  if (!requireSettings()) {
    renderSettings();
    return;
  }

  els.content.innerHTML =
    '<div class="empty"><strong>Loading...</strong><span>Please wait.</span></div>';
  try {
    await loadAll();
    if (state.view === 'structure') renderStructure();
    if (state.view === 'library') renderLibrary();
  } catch (error) {
    els.content.innerHTML = `<div class="empty"><strong>Cannot load data</strong><span>${escapeHtml(error.message)}</span></div>`;
    showNotice(error.message, true);
  }
}

function setAppLocked(isLocked) {
  document.body.classList.toggle('is-login-screen', isLocked);
  if (els.appShell) els.appShell.hidden = isLocked;
  if (els.logoutBtn) els.logoutBtn.hidden = isLocked;
}

function ensureAuthRoot() {
  let root = document.querySelector('#authRoot');
  if (!root) {
    root = document.createElement('main');
    root.id = 'authRoot';
    root.className = 'auth-root';
    document.body.prepend(root);
  }
  return root;
}

function hideLogin() {
  const root = document.querySelector('#authRoot');
  if (root) root.hidden = true;
  setAppLocked(false);
}

function renderConfigError() {
  closeEditor();
  const root = ensureAuthRoot();
  root.hidden = false;
  setAppLocked(true);
  root.innerHTML = `
    <section class="auth-card">
      <div class="auth-card__mark">L</div>
      <h1>${escapeHtml(adminConfig.appName || 'Lexor Media Gallery Admin')}</h1>
      <div class="auth-alert">Admin API is not configured. Set <code>apiBase</code> in <code>admin/assets/admin-config.js</code> before deployment.</div>
    </section>
  `;
}

function renderLogin(message = '') {
  closeEditor();
  const root = ensureAuthRoot();
  const { username } = getSettings();
  root.hidden = false;
  setAppLocked(true);
  root.innerHTML = `
    <section class="auth-card">
      <div class="auth-card__mark">L</div>
      <h1>${escapeHtml(adminConfig.appName || 'Lexor Media Gallery Admin')}</h1>
      <p>Login to manage gallery content.</p>
      ${message ? `<div class="auth-alert">${escapeHtml(message)}</div>` : ''}
      <form id="loginForm" class="auth-form">
        <div class="field field--full">
          <label for="loginUsername">Username</label>
          <input id="loginUsername" type="text" autocomplete="username" placeholder="Enter username" value="${escapeHtml(username)}" required autofocus>
        </div>
        <div class="field field--full">
          <label for="loginPassword">Password</label>
          <input id="loginPassword" type="password" autocomplete="current-password" placeholder="Enter password" required>
        </div>
        <label class="field field--checkbox auth-remember">
          <input id="rememberLogin" type="checkbox" ${adminConfig.rememberLogin ? 'checked' : ''}>
          <span>Remember login on this browser</span>
        </label>
        <button class="button auth-submit" type="submit">Login</button>
      </form>
    </section>
  `;
  root.querySelector('#loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const usernameInput = root.querySelector('#loginUsername');
    const passwordInput = root.querySelector('#loginPassword');
    const rememberInput = root.querySelector('#rememberLogin');
    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    const remember = rememberInput.checked;

    try {
      await loginWithCredentials(username, password, remember);
    } catch (error) {
      clearAdminAuth();
      renderLogin(error.message || 'Cannot login. Check username or password.');
      return;
    }

    hideLogin();
    state.view = 'structure';
    updateNav();
    await loadView();
  });
}

async function boot() {
  if (!getSettings().apiBase) {
    renderConfigError();
    return;
  }
  if (!getSettings().authToken) {
    renderLogin();
    return;
  }
  const ok = await verifyLogin();
  if (!ok) {
    clearAdminAuth();
    renderLogin('Your saved login is invalid or expired. Please login again.');
    return;
  }
  hideLogin();
  await loadView();
}

function renderSettings() {
  const { apiBase, authToken, username } = getSettings();
  els.content.innerHTML = `
    <div class="settings-panel">
      <div class="auth-status">
        <strong>Admin API</strong>
        <span>${escapeHtml(apiBase || 'Not configured')}</span>
      </div>
      <div class="auth-status">
        <strong>Login status</strong>
        <span>${authToken ? `Logged in${username ? ` as ${escapeHtml(username)}` : ''}.` : 'Not logged in.'}</span>
      </div>
      <div class="settings-actions">
        <button class="button button--ghost" id="goLogin">Login again</button>
        <button class="button button--danger" id="clearLogin">Clear saved login</button>
      </div>
    </div>
  `;
  document.querySelector('#goLogin').addEventListener('click', () => renderLogin());
  document.querySelector('#clearLogin').addEventListener('click', () => {
    clearAdminAuth();
    showNotice('Saved login cleared.');
    renderLogin();
  });
}

function renderStructure() {
  if (!state.refs.categories.length) {
    els.content.innerHTML = `
      <div class="structure-toolbar">
        <div class="structure-toolbar__title"><strong>Gallery structure</strong><span class="text-muted small">Start with a top-level category.</span></div>
        <button class="button" data-open="categories">Add category</button>
      </div>
      <div class="tree-empty"><strong>No categories yet</strong><span>Create the first category to start.</span></div>
    `;
    bindStructureActions();
    return;
  }

  els.content.innerHTML = `
    <div class="structure-toolbar">
      <div class="structure-toolbar__title">
        <strong>Gallery structure</strong>
        <span class="text-muted small">Drag categories, sub categories, folders or media rows to reorder within the same parent.</span>
      </div>
      <button class="button" data-open="categories">Add category</button>
    </div>
    <div class="tree" data-tree>
      ${state.refs.categories
        .sort(bySort)
        .map((category) => renderCategoryCard(category))
        .join('')}
    </div>
  `;
  bindStructureActions();
  bindDragSort();
}

function renderCategoryCard(category) {
  const subs = state.refs.subCategories
    .filter((sub) => sub.category_id === category.id)
    .sort(bySort);
  const folderCount = state.refs.folders.filter(
    (folder) => folder.category_id === category.id,
  ).length;
  const mediaCount = state.refs.media.filter(
    (media) => media.category_id === category.id,
  ).length;
  return `
    <article class="tree-card" data-card="category" data-id="${escapeHtml(category.id)}">
      <div class="tree-row tree-row--category" draggable="true" data-drag-resource="categories" data-drag-id="${escapeHtml(category.id)}" data-drag-scope="root">
        <span class="tree-row__handle">⋮⋮</span>
        <div class="tree-row__main">
          <button class="collapse-btn" data-action="collapse" aria-label="Collapse">⌄</button>
          <span class="tree-row__icon">${category.icon_svg || icons.category}</span>
          <div class="tree-row__text">
            <div class="tree-row__title">${escapeHtml(category.title)}</div>
            <div class="tree-row__meta">
              <span>${escapeHtml(category.handle)}</span>
              <span class="badge ${category.is_active ? 'is-active' : 'is-hidden'}">${category.is_active ? 'Visible' : 'Hidden'}</span>
              <span>${subs.length} sub</span>
              <span>${folderCount} folders</span>
              <span>${mediaCount} media</span>
            </div>
          </div>
        </div>
        <div class="tree-row__actions">
          <button class="button button--small button--ghost" data-open="sub-categories" data-category-id="${escapeHtml(category.id)}">Add sub</button>
          <button class="button button--small button--ghost" data-edit="categories" data-id="${escapeHtml(category.id)}">Edit</button>
          <button class="button button--small button--danger" data-delete="categories" data-id="${escapeHtml(category.id)}">Delete</button>
        </div>
      </div>
      <div class="tree-card__children">
        ${subs.map((sub) => renderSubRow(sub, category)).join('')}
        <button class="tree-row tree-row--placeholder" data-open="sub-categories" data-category-id="${escapeHtml(category.id)}">
          <span class="tree-row__icon">＋</span>
          <span>Add sub category inside ${escapeHtml(category.title)}</span>
        </button>
      </div>
    </article>
  `;
}

function renderSubRow(sub, category) {
  const folders = state.refs.folders
    .filter((folder) => folder.sub_category_id === sub.id)
    .sort(bySort);
  const directMedia = state.refs.media
    .filter((media) => media.sub_category_id === sub.id && !media.folder_id)
    .sort(bySort)
    .slice(0, 8);
  const totalMedia = state.refs.media.filter(
    (media) => media.sub_category_id === sub.id,
  ).length;
  return `
    <section class="tree-sub-block" data-sub-block="${escapeHtml(sub.id)}">
      <div class="tree-row tree-row--sub" draggable="true" data-drag-resource="sub-categories" data-drag-id="${escapeHtml(sub.id)}" data-drag-scope="cat:${escapeHtml(category.id)}">
        <span class="tree-row__handle">⋮⋮</span>
        <div class="tree-row__main">
          <span class="tree-row__icon">${icons.sub}</span>
          <div class="tree-row__text">
            <div class="tree-row__title">${escapeHtml(sub.title)}</div>
            <div class="tree-row__meta">
              <span>${escapeHtml(sub.handle)}</span>
              <span class="badge ${sub.is_active ? 'is-active' : 'is-hidden'}">${sub.is_active ? 'Visible' : 'Hidden'}</span>
              <span>${folders.length} folders</span>
              <span>${totalMedia} media</span>
            </div>
          </div>
        </div>
        <div class="tree-row__actions">
          <button class="button button--small button--ghost" data-open="folders" data-category-id="${escapeHtml(category.id)}" data-sub-category-id="${escapeHtml(sub.id)}">Add folder</button>
          <button class="button button--small button--ghost" data-open="media" data-category-id="${escapeHtml(category.id)}" data-sub-category-id="${escapeHtml(sub.id)}">Add media</button>
          <button class="button button--small button--ghost" data-edit="sub-categories" data-id="${escapeHtml(sub.id)}">Edit</button>
          <button class="button button--small button--danger" data-delete="sub-categories" data-id="${escapeHtml(sub.id)}">Delete</button>
        </div>
      </div>
      ${folders.map((folder) => renderFolderRow(folder, category, sub)).join('')}
      ${directMedia.map((media) => renderMediaTreeRow(media, `sub:${sub.id}`)).join('')}
      <button class="tree-row tree-row--placeholder" data-open="media" data-category-id="${escapeHtml(category.id)}" data-sub-category-id="${escapeHtml(sub.id)}">
        <span class="tree-row__icon">＋</span>
        <span>Add image/video directly inside ${escapeHtml(sub.title)}</span>
      </button>
    </section>
  `;
}

function renderFolderRow(folder, category, sub) {
  const media = state.refs.media
    .filter((item) => item.folder_id === folder.id)
    .sort(bySort)
    .slice(0, 6);
  const totalMedia = state.refs.media.filter(
    (item) => item.folder_id === folder.id,
  ).length;
  return `
    <section class="tree-folder-block" data-folder-block="${escapeHtml(folder.id)}">
      <div class="tree-row tree-row--folder" draggable="true" data-drag-resource="folders" data-drag-id="${escapeHtml(folder.id)}" data-drag-scope="sub:${escapeHtml(sub.id)}">
        <span class="tree-row__handle">⋮⋮</span>
        <div class="tree-row__main">
          <span class="tree-row__icon">${icons.folder}</span>
          <div class="tree-row__text">
            <div class="tree-row__title">${escapeHtml(folder.title)}</div>
            <div class="tree-row__meta">
              <span>${escapeHtml(folder.handle)}</span>
              <span class="badge ${folder.is_active ? 'is-active' : 'is-hidden'}">${folder.is_active ? 'Visible' : 'Hidden'}</span>
              <span>${totalMedia} media</span>
            </div>
          </div>
        </div>
        <div class="tree-row__actions">
          <button class="button button--small button--ghost" data-open="media" data-category-id="${escapeHtml(category.id)}" data-sub-category-id="${escapeHtml(sub.id)}" data-folder-id="${escapeHtml(folder.id)}">Add media</button>
          <button class="button button--small button--ghost" data-edit="folders" data-id="${escapeHtml(folder.id)}">Edit</button>
          <button class="button button--small button--danger" data-delete="folders" data-id="${escapeHtml(folder.id)}">Delete</button>
        </div>
      </div>
      ${media.map((item) => renderMediaTreeRow(item, `folder:${folder.id}`)).join('')}
      <button class="tree-row tree-row--placeholder" data-open="media" data-category-id="${escapeHtml(category.id)}" data-sub-category-id="${escapeHtml(sub.id)}" data-folder-id="${escapeHtml(folder.id)}">
        <span class="tree-row__icon">＋</span>
        <span>Add media inside ${escapeHtml(folder.title)}</span>
      </button>
    </section>
  `;
}

function renderMediaTreeRow(item, scope) {
  return `
    <div class="tree-row tree-row--media" draggable="true" data-drag-resource="media" data-drag-id="${escapeHtml(item.id)}" data-drag-scope="${escapeHtml(scope)}">
      <span class="tree-row__handle">⋮⋮</span>
      <div class="tree-row__main">
        ${renderPreview(item)}
        <div class="tree-row__text">
          <div class="tree-row__title">${escapeHtml(item.title || 'Untitled media')}</div>
          <div class="tree-row__meta">
            <span class="badge">${escapeHtml(item.media_type)} / ${escapeHtml(item.source_type)}</span>
            <span class="badge ${item.is_active ? 'is-active' : 'is-hidden'}">${item.is_active ? 'Visible' : 'Hidden'}</span>
          </div>
        </div>
      </div>
      <div class="tree-row__actions">
        <button class="button button--small button--ghost" data-edit="media" data-id="${escapeHtml(item.id)}">Edit</button>
        <button class="button button--small button--danger" data-delete="media" data-id="${escapeHtml(item.id)}">Delete</button>
      </div>
    </div>
  `;
}

function renderLibrary() {
  const categories = state.refs.categories.sort(bySort);
  const subOptions = getSubOptions(state.filters.category_id);
  const folderOptions = getFolderOptions(
    state.filters.category_id,
    state.filters.sub_category_id,
  );
  const rows = state.refs.media
    .filter((item) => {
      if (
        state.filters.category_id &&
        item.category_id !== state.filters.category_id
      )
        return false;
      if (
        state.filters.sub_category_id &&
        item.sub_category_id !== state.filters.sub_category_id
      )
        return false;
      if (state.filters.folder_id && item.folder_id !== state.filters.folder_id)
        return false;
      if (
        state.filters.media_type &&
        item.media_type !== state.filters.media_type
      )
        return false;
      return true;
    })
    .sort(bySort);

  els.content.innerHTML = `
    <div class="library-toolbar">
      ${selectControl('filter-category', 'Category', state.filters.category_id, [{ id: '', title: 'All categories' }, ...categories])}
      ${selectControl('filter-sub', 'Sub Category', state.filters.sub_category_id, [{ id: '', title: 'All sub categories' }, ...subOptions])}
      ${selectControl('filter-folder', 'Folder', state.filters.folder_id, [{ id: '', title: 'All folders / direct media' }, ...folderOptions])}
      ${selectControl('filter-type', 'Type', state.filters.media_type, [
        { id: '', title: 'All types' },
        { id: 'image', title: 'Images' },
        { id: 'video', title: 'Videos' },
      ])}
      <button class="button" data-open="media">Add media</button>
    </div>
    ${rows.length ? renderMediaTable(rows) : '<div class="empty"><strong>No media found</strong><span>Change filters or add a media item.</span></div>'}
  `;
  bindLibraryActions();
}

function selectControl(id, label, value, options) {
  return `
    <div class="field">
      <label for="${id}">${escapeHtml(label)}</label>
      <select id="${id}" data-filter="${id}">
        ${options.map((opt) => `<option value="${escapeHtml(opt.id)}" ${String(opt.id) === String(value) ? 'selected' : ''}>${escapeHtml(opt.title)}</option>`).join('')}
      </select>
    </div>
  `;
}

function renderMediaTable(rows) {
  return `
    <div class="table-wrap">
      <table>
        <thead><tr><th>Preview</th><th>Title</th><th>Location</th><th class="col-type">Type</th><th>Sort</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          ${rows
            .map(
              (item) => `
            <tr>
              <td>${renderPreview(item)}</td>
              <td><strong>${escapeHtml(item.title || 'Untitled')}</strong><br><span class="text-muted truncate">${escapeHtml(item.url)}</span></td>
              <td class="small">
                ${escapeHtml(titleOf(state.refs.categories, item.category_id))}<br>
                <span class="text-muted">${escapeHtml(titleOf(state.refs.subCategories, item.sub_category_id))}${item.folder_id ? ` / ${escapeHtml(titleOf(state.refs.folders, item.folder_id))}` : ''}</span>
              </td>
              <td><span class="badge badge-${escapeHtml(item.source_type)}">${escapeHtml(item.media_type)} / ${escapeHtml(item.source_type)}</span></td>
              <td>${escapeHtml(item.sort_order)}</td>
              <td><span class="badge ${item.is_active ? 'is-active' : 'is-hidden'}">${item.is_active ? 'Visible' : 'Hidden'}</span></td>
              <td><div class="actions"><button class="button button--small button--ghost" data-edit="media" data-id="${escapeHtml(item.id)}">Edit</button><button class="button button--small button--danger" data-delete="media" data-id="${escapeHtml(item.id)}">Delete</button></div></td>
            </tr>
          `,
            )
            .join('')}
        </tbody>
      </table>
    </div>
  `;
}

function bindStructureActions() {
  els.content
    .querySelectorAll('[data-open]')
    .forEach((btn) =>
      btn.addEventListener('click', () =>
        openEditor(btn.dataset.open, null, btn.dataset),
      ),
    );
  els.content
    .querySelectorAll('[data-edit]')
    .forEach((btn) =>
      btn.addEventListener('click', () =>
        openEditor(
          btn.dataset.edit,
          findItem(btn.dataset.edit, btn.dataset.id),
          {},
        ),
      ),
    );
  els.content
    .querySelectorAll('[data-delete]')
    .forEach((btn) =>
      btn.addEventListener('click', () =>
        deleteItem(btn.dataset.delete, btn.dataset.id),
      ),
    );
  els.content
    .querySelectorAll('[data-action="collapse"]')
    .forEach((btn) =>
      btn.addEventListener('click', () =>
        btn.closest('.tree-card')?.classList.toggle('is-collapsed'),
      ),
    );
}

function bindLibraryActions() {
  bindStructureActions();
  els.content.querySelectorAll('[data-filter]').forEach((select) => {
    select.addEventListener('change', () => {
      const map = {
        'filter-category': 'category_id',
        'filter-sub': 'sub_category_id',
        'filter-folder': 'folder_id',
        'filter-type': 'media_type',
      };
      state.filters[map[select.dataset.filter]] = select.value;
      if (select.dataset.filter === 'filter-category') {
        state.filters.sub_category_id = '';
        state.filters.folder_id = '';
      }
      if (select.dataset.filter === 'filter-sub') state.filters.folder_id = '';
      renderLibrary();
    });
  });
}

function bindDragSort() {
  let dragged = null;
  els.content.querySelectorAll('[draggable="true"]').forEach((row) => {
    row.addEventListener('dragstart', (event) => {
      dragged = row;
      row.classList.add('is-dragging');
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', row.dataset.dragId || '');
    });
    row.addEventListener('dragend', () => {
      row.classList.remove('is-dragging');
      dragged = null;
    });
    row.addEventListener('dragover', (event) => {
      if (!dragged || dragged === row) return;
      if (dragged.dataset.dragResource !== row.dataset.dragResource) return;
      if (dragged.dataset.dragScope !== row.dataset.dragScope) return;
      event.preventDefault();
      const rect = row.getBoundingClientRect();
      const before = event.clientY < rect.top + rect.height / 2;
      row.parentNode.insertBefore(dragged, before ? row : row.nextSibling);
    });
    row.addEventListener('drop', async (event) => {
      event.preventDefault();
      if (!dragged) return;
      await persistOrder(
        dragged.dataset.dragResource,
        dragged.dataset.dragScope,
      );
    });
  });
}

async function persistOrder(resource, scope) {
  const rows = Array.from(
    els.content.querySelectorAll(
      `[data-drag-resource="${CSS.escape(resource)}"][data-drag-scope="${CSS.escape(scope)}"]`,
    ),
  );
  const path = resourceMeta[resource].path;
  try {
    await Promise.all(
      rows.map((row, index) =>
        api(`${path}/${row.dataset.dragId}`, {
          method: 'PATCH',
          body: JSON.stringify({ sort_order: index * 10 }),
        }),
      ),
    );
    showNotice('Sort order saved.');
    await loadAll();
  } catch (error) {
    showNotice(error.message, true);
    await loadView();
  }
}

function findItem(resource, id) {
  const map = {
    categories: state.refs.categories,
    'sub-categories': state.refs.subCategories,
    folders: state.refs.folders,
    media: state.refs.media,
  };
  return map[resource].find((item) => String(item.id) === String(id));
}

function openEditor(resource, item = null, rawContext = {}) {
  const context = {
    category_id:
      rawContext.categoryId ||
      rawContext.category_id ||
      item?.category_id ||
      '',
    sub_category_id:
      rawContext.subCategoryId ||
      rawContext.sub_category_id ||
      item?.sub_category_id ||
      '',
    folder_id:
      rawContext.folderId || rawContext.folder_id || item?.folder_id || '',
  };
  state.editing = { resource, id: item?.id || '', context };
  const label = resourceMeta[resource].label;
  els.dialogTitle.textContent = item ? `Edit ${label}` : `Add ${label}`;
  els.dialogDescription.textContent = getDialogDescription(resource, context);
  els.formFields.innerHTML = getFields(resource, item || {}, context)
    .map(renderField)
    .join('');
  els.editForm.dataset.resource = resource;
  els.editForm.dataset.id = item?.id || '';
  bindConditionalForm(resource);
  els.dialog.showModal();
}

function getDialogDescription(resource, context) {
  if (resource === 'categories') return 'Top-level sidebar group.';
  if (resource === 'sub-categories')
    return `Child item inside ${titleOf(state.refs.categories, context.category_id)}.`;
  if (resource === 'folders')
    return `Folder card inside ${titleOf(state.refs.subCategories, context.sub_category_id)}.`;
  return `Image or video inside ${context.folder_id ? titleOf(state.refs.folders, context.folder_id) : titleOf(state.refs.subCategories, context.sub_category_id)}.`;
}

function getFields(resource, item = {}, context = {}) {
  if (resource === 'categories') {
    return [
      field('title', 'Title', 'text', item.title, true),
      field(
        'handle',
        'Handle',
        'text',
        item.handle,
        false,
        'Leave blank when creating to auto-generate from title.',
      ),
      field(
        'sort_order',
        'Sort order',
        'number',
        item.sort_order ?? nextSort(state.refs.categories),
      ),
      field('is_active', 'Visible', 'checkbox', item.is_active ?? true),
      field(
        'icon_svg',
        'Custom SVG icon',
        'textarea',
        item.icon_svg,
        false,
        'Optional. Paste trusted inline SVG code.',
        true,
      ),
    ];
  }

  if (resource === 'sub-categories') {
    const categoryId =
      item.category_id ||
      context.category_id ||
      state.refs.categories[0]?.id ||
      '';
    return [
      field(
        'category_id',
        'Parent category',
        'select',
        categoryId,
        true,
        '',
        false,
        state.refs.categories.sort(bySort),
      ),
      field('title', 'Title', 'text', item.title, true),
      field(
        'handle',
        'Handle',
        'text',
        item.handle,
        false,
        'Leave blank when creating to auto-generate from title.',
      ),
      field(
        'sort_order',
        'Sort order',
        'number',
        item.sort_order ??
          nextSort(state.refs.subCategories, 'category_id', categoryId),
      ),
      field('is_active', 'Visible', 'checkbox', item.is_active ?? true),
    ];
  }

  if (resource === 'folders') {
    const categoryId =
      item.category_id ||
      context.category_id ||
      state.refs.categories[0]?.id ||
      '';
    const subId =
      item.sub_category_id ||
      context.sub_category_id ||
      getSubOptions(categoryId)[0]?.id ||
      '';
    return [
      field(
        'category_id',
        'Parent category',
        'select',
        categoryId,
        true,
        '',
        false,
        state.refs.categories.sort(bySort),
      ),
      field(
        'sub_category_id',
        'Parent sub category',
        'select',
        subId,
        true,
        'Only sub categories inside selected category are shown.',
        false,
        getSubOptions(categoryId),
      ),
      field('title', 'Folder title', 'text', item.title, true),
      field(
        'handle',
        'Handle',
        'text',
        item.handle,
        false,
        'Leave blank when creating to auto-generate from title.',
      ),
      field(
        'cover_image_url',
        'Cover image URL',
        'url',
        item.cover_image_url,
        false,
        'Optional. If blank, storefront uses the first item thumbnail.',
        true,
      ),
      field(
        'description',
        'Description',
        'textarea',
        item.description,
        false,
        '',
        true,
      ),
      field(
        'sort_order',
        'Sort order',
        'number',
        item.sort_order ??
          nextSort(state.refs.folders, 'sub_category_id', subId),
      ),
      field('is_active', 'Visible', 'checkbox', item.is_active ?? true),
    ];
  }

  const categoryId =
    item.category_id ||
    context.category_id ||
    state.refs.categories[0]?.id ||
    '';
  const subId =
    item.sub_category_id ||
    context.sub_category_id ||
    getSubOptions(categoryId)[0]?.id ||
    '';
  const folderId = item.folder_id || context.folder_id || '';
  const folderOptions = [
    { id: '', title: 'No folder: show directly in sub category' },
    ...getFolderOptions(categoryId, subId),
  ];
  return [
    field(
      'category_id',
      'Parent category',
      'select',
      categoryId,
      true,
      '',
      false,
      state.refs.categories.sort(bySort),
    ),
    field(
      'sub_category_id',
      'Parent sub category',
      'select',
      subId,
      true,
      'Only sub categories inside selected category are shown.',
      false,
      getSubOptions(categoryId),
    ),
    field(
      'folder_id',
      'Folder',
      'select',
      folderId,
      false,
      'Optional. Select a folder or leave blank for direct media.',
      false,
      folderOptions,
    ),
    field(
      'media_type',
      'Media type',
      'select',
      item.media_type || inferMediaType(item.url) || 'image',
      true,
      '',
      false,
      [
        { id: 'image', title: 'Image' },
        { id: 'video', title: 'Video' },
      ],
    ),
    field(
      'source_type',
      'Source type',
      'select',
      item.source_type || inferSourceType(item.url) || 'shopify',
      true,
      '',
      false,
      [
        { id: 'shopify', title: 'Shopify Files/CDN' },
        { id: 'youtube', title: 'YouTube' },
        { id: 'external', title: 'External CDN URL' },
      ],
    ),
    field('title', 'Title', 'text', item.title, true),
    field(
      'url',
      'Media URL',
      'url',
      item.url,
      true,
      'Image URL, Shopify video URL, YouTube URL, or external CDN URL.',
      true,
    ),
    field(
      'thumbnail_url',
      'Thumbnail / poster URL',
      'url',
      item.thumbnail_url,
      false,
      'Optional. YouTube auto-generates thumbnail if blank. Shopify MP4 can preview itself, but a poster image is better.',
      true,
    ),
    field(
      'alt',
      'Alt text',
      'text',
      item.alt,
      false,
      'Recommended for photos.',
      true,
    ),
    field(
      'description',
      'Description',
      'textarea',
      item.description,
      false,
      '',
      true,
    ),
    field(
      'sort_order',
      'Sort order',
      'number',
      item.sort_order ??
        nextSort(
          state.refs.media,
          folderId ? 'folder_id' : 'sub_category_id',
          folderId || subId,
        ),
    ),
    field('is_active', 'Visible', 'checkbox', item.is_active ?? true),
  ];
}

function field(
  name,
  label,
  type,
  value,
  required = false,
  help = '',
  full = false,
  options = [],
) {
  return { name, label, type, value, required, help, full, options };
}

function renderField(config) {
  const required = config.required ? 'required' : '';
  const value = config.value ?? '';
  let control = '';
  if (config.type === 'textarea') {
    control = `<textarea id="field-${config.name}" name="${config.name}" ${required}>${escapeHtml(value)}</textarea>`;
  } else if (config.type === 'select') {
    control = `<select id="field-${config.name}" name="${config.name}" ${required}>${(config.options || []).map((opt) => `<option value="${escapeHtml(opt.id)}" ${String(opt.id) === String(value) ? 'selected' : ''}>${escapeHtml(opt.title)}</option>`).join('')}</select>`;
  } else if (config.type === 'checkbox') {
    return `<label class="field field--checkbox"><input id="field-${config.name}" name="${config.name}" type="checkbox" ${value ? 'checked' : ''}> <span>${escapeHtml(config.label)}</span></label>`;
  } else {
    control = `<input id="field-${config.name}" name="${config.name}" type="${config.type}" value="${escapeHtml(value)}" ${required}>`;
  }
  return `<div class="field ${config.full ? 'field--full' : ''}"><label for="field-${config.name}">${escapeHtml(config.label)}</label>${control}${config.help ? `<small>${escapeHtml(config.help)}</small>` : ''}</div>`;
}

function bindConditionalForm(resource) {
  const category = els.formFields.querySelector('[name="category_id"]');
  const sub = els.formFields.querySelector('[name="sub_category_id"]');
  const folder = els.formFields.querySelector('[name="folder_id"]');
  const url = els.formFields.querySelector('[name="url"]');
  const mediaType = els.formFields.querySelector('[name="media_type"]');
  const sourceType = els.formFields.querySelector('[name="source_type"]');

  if (category) {
    category.addEventListener('change', () => {
      if (sub) {
        const subs = getSubOptions(category.value);
        sub.innerHTML = subs
          .map(
            (opt) =>
              `<option value="${escapeHtml(opt.id)}">${escapeHtml(opt.title)}</option>`,
          )
          .join('');
      }
      if (folder) {
        const folders = [
          { id: '', title: 'No folder: show directly in sub category' },
          ...getFolderOptions(category.value, sub?.value || ''),
        ];
        folder.innerHTML = folders
          .map(
            (opt) =>
              `<option value="${escapeHtml(opt.id)}">${escapeHtml(opt.title)}</option>`,
          )
          .join('');
      }
    });
  }
  if (sub && folder) {
    sub.addEventListener('change', () => {
      const folders = [
        { id: '', title: 'No folder: show directly in sub category' },
        ...getFolderOptions(category?.value || '', sub.value),
      ];
      folder.innerHTML = folders
        .map(
          (opt) =>
            `<option value="${escapeHtml(opt.id)}">${escapeHtml(opt.title)}</option>`,
        )
        .join('');
    });
  }
  if (url && mediaType && sourceType) {
    url.addEventListener('input', () => {
      const src = url.value.trim();
      const inferredType = inferMediaType(src);
      const inferredSource = inferSourceType(src);
      if (inferredType) mediaType.value = inferredType;
      if (inferredSource) sourceType.value = inferredSource;
    });
  }
}

function inferSourceType(url) {
  if (!url) return '';
  if (/youtu\.be|youtube\.com/i.test(url)) return 'youtube';
  if (/cdn\.shopify\.com/i.test(url)) return 'shopify';
  return 'external';
}

function inferMediaType(url) {
  if (!url) return '';
  if (/youtu\.be|youtube\.com/i.test(url)) return 'video';
  if (/\.(mp4|m4v|mov|webm|ogv)(\?|#|$)/i.test(url)) return 'video';
  if (/\.(jpg|jpeg|png|gif|webp|avif|svg)(\?|#|$)/i.test(url)) return 'image';
  return '';
}

async function saveEditor(event) {
  if (event.submitter?.value !== 'save') return;
  event.preventDefault();
  const resource = els.editForm.dataset.resource;
  const id = els.editForm.dataset.id;
  const fields = getFields(resource, {}, state.editing.context);
  const payload = {};
  for (const config of fields) {
    const input = els.formFields.querySelector(`[name="${config.name}"]`);
    if (!input) continue;
    if (config.type === 'checkbox') payload[config.name] = input.checked;
    else if (config.type === 'number')
      payload[config.name] = Number(input.value || 0);
    else {
      payload[config.name] = input.value.trim();
      if (
        payload[config.name] === '' &&
        [
          'folder_id',
          'thumbnail_url',
          'cover_image_url',
          'icon_svg',
          'alt',
          'description',
          'handle',
        ].includes(config.name)
      )
        payload[config.name] = null;
    }
  }
  try {
    const path = resourceMeta[resource].path;
    if (id) {
      await api(`${path}/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      });
      showNotice('Updated successfully.');
    } else {
      await api(path, { method: 'POST', body: JSON.stringify(payload) });
      showNotice('Created successfully.');
    }
    els.dialog.close();
    await loadView();
  } catch (error) {
    showNotice(error.message, true);
  }
}

async function deleteItem(resource, id) {
  const label = resourceMeta[resource].label;
  if (!confirm(`Delete this ${label}? This cannot be undone.`)) return;
  try {
    await api(`${resourceMeta[resource].path}/${id}`, { method: 'DELETE' });
    showNotice('Deleted successfully.');
    await loadView();
  } catch (error) {
    showNotice(error.message, true);
  }
}

function renderPreview(item) {
  const src =
    item.thumbnail_url ||
    (item.media_type === 'image' ? item.url : youtubeThumbnail(item.url));
  if (src)
    return `<img class="media-thumb" src="${escapeHtml(src)}" alt="" width="88" height="56">`;
  if (
    item.media_type === 'video' &&
    /\.(mp4|m4v|mov|webm|ogv)(\?|#|$)/i.test(item.url || '')
  )
    return `<video class="media-thumb" src="${escapeHtml(item.url)}#t=0.1" preload="metadata" muted playsinline width="88" height="56"></video>`;
  return `<span class="badge">${escapeHtml(item.media_type || 'media')}</span>`;
}

function youtubeId(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes('youtu.be'))
      return u.pathname.split('/').filter(Boolean)[0] || '';
    if (u.searchParams.get('v')) return u.searchParams.get('v');
    const parts = u.pathname.split('/').filter(Boolean);
    const index = parts.findIndex((x) =>
      ['embed', 'shorts', 'live'].includes(x),
    );
    return index >= 0 ? parts[index + 1] || '' : '';
  } catch {
    return '';
  }
}

function youtubeThumbnail(url) {
  const id = youtubeId(url || '');
  return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : '';
}

const icons = {
  category:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 21V7l8-4v18"/><path d="M12 9h8v12"/><path d="M8 11h1M8 15h1M16 13h1M16 17h1"/></svg>',
  sub: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  folder:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5v-9Z"/></svg>',
};

document.querySelectorAll('.nav__item').forEach((btn) => {
  btn.addEventListener('click', () => {
    state.view = btn.dataset.view;
    updateNav();
    loadView();
  });
});
els.refreshBtn.addEventListener('click', () => loadView());
els.newBtn.addEventListener('click', () =>
  state.view === 'library' ? openEditor('media') : openEditor('categories'),
);
if (els.logoutBtn) {
  els.logoutBtn.addEventListener('click', () => {
    clearAdminAuth();
    renderLogin('You have logged out.');
  });
}
bindDialogCloseControls();
els.editForm.addEventListener('submit', saveEditor);

boot();
