# Step 1-D1 completed — Foundation MVP

Đã chuyển nền móng project sang Cloudflare D1:

1. D1 schema và seed data.
2. Cloudflare Worker API dùng D1 binding `DB`.
3. Admin Dashboard static CRUD cơ bản.
4. Storefront Web Component hiển thị gallery.
5. Shopify section container để nhúng widget.

## Chưa làm trong Step 1-D1

- Upload tự động vào Shopify Files/CDN.
- Drag/drop sort.
- Bulk actions.
- Authentication nâng cao.
- Theme App Extension/App Block.

## Việc cần bạn chuẩn bị cho Step 2

1. Cloudflare account.
2. D1 database đã tạo.
3. Worker chạy được local với `/api/gallery/tree`.
4. Shopify Admin access token cho bước upload tự động sau này.

Nếu chưa có Shopify token, Step 2 vẫn có thể tiếp tục làm admin/widget trước và nhập Shopify CDN URL thủ công.
