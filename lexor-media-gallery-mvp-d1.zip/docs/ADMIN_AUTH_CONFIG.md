# Admin authentication config

The admin page no longer asks editors for API settings. The API URL is a public config value, and the username/password are checked by the Cloudflare Worker using environment variables.

## 1. Cloudflare Worker variables/secrets

Set the public/non-sensitive values in `worker/wrangler.toml`:

```toml
[vars]
ADMIN_USERNAME = "admin"
ADMIN_TOKEN_TTL_SECONDS = "43200"
CORS_ORIGIN = "*"
```

Set sensitive values as Wrangler secrets, not plain text in Git:

```bash
cd worker
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put ADMIN_SESSION_SECRET
npx wrangler deploy
```

`ADMIN_SESSION_SECRET` should be a long random string used to sign login tokens.

Legacy fallback: `ADMIN_SECRET` is still accepted by the Worker for older dashboards that send `X-Admin-Secret`, but new admin UI uses username/password login and `Authorization: Bearer <token>`.

## 2. Admin static config

Set the API endpoint in:

```text
admin/assets/admin-config.js
```

Example:

```js
window.LEXOR_MEDIA_ADMIN_CONFIG = {
  apiBase: 'https://lexor-media-gallery-api.lexortechdev.workers.dev',
  rememberLogin: true,
  appName: 'Lexor Media Gallery Admin'
};
```

Do not put passwords or API secrets in this file. It is public.

## 3. Login UX

Editors only see:

```text
Username
Password
Remember login on this browser
```

The Advanced API settings panel is intentionally removed.
