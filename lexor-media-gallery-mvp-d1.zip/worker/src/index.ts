export interface Env {
  DB: D1Database;
  ADMIN_USERNAME?: string;
  ADMIN_PASSWORD?: string;
  ADMIN_SESSION_SECRET?: string;
  ADMIN_TOKEN_TTL_SECONDS?: string;
  ADMIN_SECRET?: string; // Legacy fallback only. Prefer ADMIN_PASSWORD + ADMIN_SESSION_SECRET.
  CORS_ORIGIN?: string;
}

type JsonRecord = Record<string, unknown>;
type Row = Record<string, any>;

type Resource = 'categories' | 'sub-categories' | 'folders' | 'media';

const TABLE_MAP: Record<Resource, string> = {
  categories: 'categories',
  'sub-categories': 'sub_categories',
  folders: 'folders',
  media: 'media_items',
};

const FIELD_MAP: Record<Resource, string[]> = {
  categories: ['title', 'handle', 'icon_svg', 'sort_order', 'is_active'],
  'sub-categories': ['category_id', 'title', 'handle', 'sort_order', 'is_active'],
  folders: ['category_id', 'sub_category_id', 'title', 'handle', 'description', 'cover_image_url', 'sort_order', 'is_active'],
  media: [
    'category_id',
    'sub_category_id',
    'folder_id',
    'media_type',
    'source_type',
    'shopify_file_id',
    'url',
    'thumbnail_url',
    'title',
    'alt',
    'description',
    'width',
    'height',
    'duration',
    'sort_order',
    'is_active',
  ],
};

const BOOLEAN_FIELDS = new Set(['is_active']);
const NUMBER_FIELDS = new Set(['sort_order', 'width', 'height', 'duration']);

const corsHeaders = (env: Env): HeadersInit => ({
  'Access-Control-Allow-Origin': env.CORS_ORIGIN || '*',
  'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Admin-Secret',
  'Access-Control-Max-Age': '86400',
});

function json(data: unknown, init: ResponseInit = {}, env?: Env): Response {
  const headers = new Headers(init.headers);
  headers.set('Content-Type', 'application/json; charset=utf-8');
  if (env) {
    for (const [key, value] of Object.entries(corsHeaders(env))) headers.set(key, String(value));
  }
  return new Response(JSON.stringify(data, null, 2), { ...init, headers });
}

function notFound(env: Env): Response {
  return json({ error: 'Not found' }, { status: 404 }, env);
}

function badRequest(message: string, env: Env): Response {
  return json({ error: message }, { status: 400 }, env);
}

function unauthorized(env: Env): Response {
  return json({ error: 'Unauthorized' }, { status: 401 }, env);
}

function slugify(input: unknown): string {
  return String(input || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/đ/g, 'd')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120);
}


function youtubeId(input: unknown): string {
  try {
    const url = new URL(String(input || ''));
    if (url.hostname.includes('youtu.be')) return url.pathname.split('/').filter(Boolean)[0] || '';
    const v = url.searchParams.get('v');
    if (v) return v;
    const parts = url.pathname.split('/').filter(Boolean);
    const index = parts.findIndex((part) => ['embed', 'shorts'].includes(part));
    return index >= 0 ? parts[index + 1] || '' : '';
  } catch {
    return '';
  }
}

function youtubeThumbnail(input: unknown): string {
  const id = youtubeId(input);
  return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : '';
}

function fallbackThumbnailFromMedia(row: Row | null): string | null {
  if (!row) return null;
  if (row.thumbnail_url) return row.thumbnail_url;
  if (row.source_type === 'youtube') return youtubeThumbnail(row.url) || null;
  return row.url || null;
}

function toDbValue(key: string, value: unknown): string | number | null {
  if (value === undefined || value === '') return null;
  if (BOOLEAN_FIELDS.has(key)) return value ? 1 : 0;
  if (NUMBER_FIELDS.has(key)) {
    if (value === null) return null;
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  if (value === null) return null;
  return String(value);
}

function cleanPayload(resource: Resource, payload: JsonRecord): JsonRecord {
  const allowed = new Set(FIELD_MAP[resource]);
  const next: JsonRecord = {};

  for (const [key, value] of Object.entries(payload)) {
    if (!allowed.has(key)) continue;
    next[key] = toDbValue(key, value);
  }

  if (!next.handle && next.title) next.handle = slugify(next.title);
  return next;
}

function normalizeRow<T extends Row>(row: T | null | undefined): T | null {
  if (!row) return null;
  const next: Row = { ...row };
  if ('is_active' in next) next.is_active = Boolean(next.is_active);
  return next as T;
}

function normalizeRows<T extends Row>(rows: T[]): T[] {
  return rows.map((row) => normalizeRow(row)!) as T[];
}

async function all<T extends Row = Row>(env: Env, sql: string, params: unknown[] = []): Promise<T[]> {
  const stmt = env.DB.prepare(sql).bind(...params);
  const result = await stmt.all<T>();
  return normalizeRows(result.results || []);
}

async function first<T extends Row = Row>(env: Env, sql: string, params: unknown[] = []): Promise<T | null> {
  const row = await env.DB.prepare(sql).bind(...params).first<T>();
  return normalizeRow(row || null) as T | null;
}

async function run(env: Env, sql: string, params: unknown[] = []): Promise<D1Result> {
  return env.DB.prepare(sql).bind(...params).run();
}

function isResource(value: string | undefined): value is Resource {
  return Boolean(value && value in TABLE_MAP);
}

async function resolveScope(env: Env, url: URL): Promise<{
  category: Row | null;
  subCategory: Row | null;
  folder: Row | null;
}> {
  const categoryHandle = url.searchParams.get('category') || url.searchParams.get('cat');
  const subHandle = url.searchParams.get('sub') || url.searchParams.get('sub_category');
  const folderHandle = url.searchParams.get('folder');

  let category: Row | null = null;
  let subCategory: Row | null = null;
  let folder: Row | null = null;

  if (categoryHandle && categoryHandle !== 'all' && categoryHandle !== 'all-media') {
    category = await first(env, 'SELECT * FROM categories WHERE handle = ? LIMIT 1', [categoryHandle]);
  }

  if (subHandle) {
    if (category?.id) {
      subCategory = await first(env, 'SELECT * FROM sub_categories WHERE handle = ? AND category_id = ? LIMIT 1', [subHandle, category.id]);
    } else {
      subCategory = await first(env, 'SELECT * FROM sub_categories WHERE handle = ? LIMIT 1', [subHandle]);
    }
    if (!category && subCategory?.category_id) {
      category = await first(env, 'SELECT * FROM categories WHERE id = ? LIMIT 1', [subCategory.category_id]);
    }
  }

  if (folderHandle) {
    if (subCategory?.id) {
      folder = await first(env, 'SELECT * FROM folders WHERE handle = ? AND sub_category_id = ? LIMIT 1', [folderHandle, subCategory.id]);
    } else {
      folder = await first(env, 'SELECT * FROM folders WHERE handle = ? LIMIT 1', [folderHandle]);
    }
    if (!subCategory && folder?.sub_category_id) {
      subCategory = await first(env, 'SELECT * FROM sub_categories WHERE id = ? LIMIT 1', [folder.sub_category_id]);
    }
    if (!category && folder?.category_id) {
      category = await first(env, 'SELECT * FROM categories WHERE id = ? LIMIT 1', [folder.category_id]);
    }
  }

  return { category, subCategory, folder };
}

async function handleTree(request: Request, env: Env): Promise<Response> {
  const [categories, subCategories] = await Promise.all([
    all(env, 'SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC, title ASC'),
    all(env, 'SELECT * FROM sub_categories WHERE is_active = 1 ORDER BY sort_order ASC, title ASC'),
  ]);

  const subByCategory = new Map<string, Row[]>();
  for (const sub of subCategories) {
    const key = String(sub.category_id);
    if (!subByCategory.has(key)) subByCategory.set(key, []);
    subByCategory.get(key)!.push(sub);
  }

  const tree = categories.map((category) => ({
    ...category,
    sub_categories: subByCategory.get(String(category.id)) || [],
  }));

  return json({ categories: tree }, {}, env);
}

function mediaPublicFields(): string {
  return [
    'id',
    'category_id',
    'sub_category_id',
    'folder_id',
    'media_type',
    'source_type',
    'url',
    'thumbnail_url',
    'title',
    'alt',
    'description',
    'width',
    'height',
    'duration',
    'sort_order',
    'created_at',
  ].join(', ');
}

async function handleMedia(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const type = url.searchParams.get('type') || url.searchParams.get('m') || 'all';
  const page = Math.max(1, Number(url.searchParams.get('page') || 1));
  const limit = Math.min(60, Math.max(1, Number(url.searchParams.get('limit') || 36)));
  const offset = (page - 1) * limit;
  const search = (url.searchParams.get('search') || '').trim();

  if (!['all', 'image', 'video', 'folder', 'folders'].includes(type)) {
    return badRequest('Invalid type. Use all, image, video, or folder.', env);
  }

  const { category, subCategory, folder } = await resolveScope(env, url);

  const folderRowsPromise = (type === 'all' || type === 'folder' || type === 'folders') && !folder
    ? fetchFoldersForScope(env, { category, subCategory, search, limit: 200 })
    : Promise.resolve([] as Row[]);

  const includeMedia = type === 'all' || type === 'image' || type === 'video';
  const mediaRowsPromise = includeMedia
    ? fetchMediaForScope(env, { category, subCategory, folder, type, search, offset, limit })
    : Promise.resolve([] as Row[]);

  const [folders, mediaRows] = await Promise.all([folderRowsPromise, mediaRowsPromise]);

  const hasMore = mediaRows.length > limit;
  const media = hasMore ? mediaRows.slice(0, limit) : mediaRows;

  return json({
    scope: {
      category: category ? { id: category.id, title: category.title, handle: category.handle } : null,
      sub_category: subCategory ? { id: subCategory.id, title: subCategory.title, handle: subCategory.handle } : null,
      folder: folder ? { id: folder.id, title: folder.title, handle: folder.handle } : null,
      type,
    },
    page,
    limit,
    has_more: hasMore,
    folders,
    media,
  }, {}, env);
}

async function fetchFoldersForScope(env: Env, args: {
  category: Row | null;
  subCategory: Row | null;
  search: string;
  limit: number;
}): Promise<Row[]> {
  const where = ['is_active = 1'];
  const params: unknown[] = [];

  if (args.category?.id) {
    where.push('category_id = ?');
    params.push(args.category.id);
  }
  if (args.subCategory?.id) {
    where.push('sub_category_id = ?');
    params.push(args.subCategory.id);
  }
  if (args.search) {
    where.push('title LIKE ?');
    params.push(`%${args.search}%`);
  }

  params.push(args.limit);
  const folders = await all(env, `SELECT * FROM folders WHERE ${where.join(' AND ')} ORDER BY sort_order ASC, title ASC LIMIT ?`, params);

  await Promise.all(folders.map(async (folder) => {
    if (folder.cover_image_url) return;
    const firstMedia = await first(env, `
      SELECT thumbnail_url, url, media_type, source_type
      FROM media_items
      WHERE folder_id = ? AND is_active = 1
      ORDER BY sort_order ASC, created_at DESC
      LIMIT 1
    `, [folder.id]);
    folder.cover_image_url = fallbackThumbnailFromMedia(firstMedia);
  }));

  return folders;
}

async function fetchMediaForScope(env: Env, args: {
  category: Row | null;
  subCategory: Row | null;
  folder: Row | null;
  type: string;
  search: string;
  offset: number;
  limit: number;
}): Promise<Row[]> {
  const where = ['is_active = 1'];
  const params: unknown[] = [];

  if (args.category?.id) {
    where.push('category_id = ?');
    params.push(args.category.id);
  }
  if (args.subCategory?.id) {
    where.push('sub_category_id = ?');
    params.push(args.subCategory.id);
  }
  if (args.folder?.id) {
    where.push('folder_id = ?');
    params.push(args.folder.id);
  } else if (args.type === 'all') {
    // All Media inside a sub category should show folders first + direct media only.
    // Videos/Photos tabs can include media inside child folders.
    where.push('folder_id IS NULL');
  }
  if (args.type === 'image' || args.type === 'video') {
    where.push('media_type = ?');
    params.push(args.type);
  }
  if (args.search) {
    where.push('title LIKE ?');
    params.push(`%${args.search}%`);
  }

  params.push(args.limit + 1, args.offset);
  return all(env, `
    SELECT ${mediaPublicFields()}
    FROM media_items
    WHERE ${where.join(' AND ')}
    ORDER BY sort_order ASC, created_at DESC
    LIMIT ? OFFSET ?
  `, params);
}


function base64UrlEncode(input: ArrayBuffer | Uint8Array | string): string {
  let bytes: Uint8Array;
  if (typeof input === 'string') {
    bytes = new TextEncoder().encode(input);
  } else if (input instanceof Uint8Array) {
    bytes = input;
  } else {
    bytes = new Uint8Array(input);
  }

  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });

  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function base64UrlDecode(value: string): Uint8Array {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function getAdminUsername(env: Env): string {
  return String(env.ADMIN_USERNAME || 'admin');
}

function getAdminPassword(env: Env): string {
  // ADMIN_SECRET is kept as a migration fallback so old deployments do not break.
  return String(env.ADMIN_PASSWORD || env.ADMIN_SECRET || '');
}

function getSessionSecret(env: Env): string {
  return String(env.ADMIN_SESSION_SECRET || env.ADMIN_SECRET || env.ADMIN_PASSWORD || '');
}

function getTokenTtlSeconds(env: Env): number {
  const value = Number(env.ADMIN_TOKEN_TTL_SECONDS || 60 * 60 * 12);
  return Number.isFinite(value) && value > 0 ? Math.floor(value) : 60 * 60 * 12;
}

function safeEqual(a: string, b: string): boolean {
  const left = new TextEncoder().encode(a);
  const right = new TextEncoder().encode(b);
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i += 1) diff |= left[i] ^ right[i];
  return diff === 0;
}

async function hmacSha256(secret: string, value: string): Promise<ArrayBuffer> {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  return crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
}

async function createAdminToken(env: Env, username: string): Promise<{ token: string; expires_at: string }> {
  const ttl = getTokenTtlSeconds(env);
  const expiresAt = Math.floor(Date.now() / 1000) + ttl;
  const payload = base64UrlEncode(JSON.stringify({ sub: username, exp: expiresAt, iat: Math.floor(Date.now() / 1000) }));
  const signature = base64UrlEncode(await hmacSha256(getSessionSecret(env), payload));
  return {
    token: `${payload}.${signature}`,
    expires_at: new Date(expiresAt * 1000).toISOString(),
  };
}

async function verifyAdminToken(env: Env, token: string): Promise<boolean> {
  if (!token || !getSessionSecret(env)) return false;
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return false;

  const expected = base64UrlEncode(await hmacSha256(getSessionSecret(env), payload));
  if (!safeEqual(signature, expected)) return false;

  try {
    const payloadJson = new TextDecoder().decode(base64UrlDecode(payload));
    const data = JSON.parse(payloadJson) as { exp?: number; sub?: string };
    if (!data.sub || !data.exp) return false;
    return data.exp > Math.floor(Date.now() / 1000);
  } catch {
    return false;
  }
}

async function isAdmin(request: Request, env: Env): Promise<boolean> {
  const auth = request.headers.get('Authorization') || '';
  const bearer = auth.startsWith('Bearer ') ? auth.slice('Bearer '.length).trim() : '';
  if (bearer && await verifyAdminToken(env, bearer)) return true;

  // Legacy fallback for previous dashboard builds that still send X-Admin-Secret.
  const legacySecret = request.headers.get('X-Admin-Secret') || '';
  return Boolean(env.ADMIN_SECRET && legacySecret && safeEqual(legacySecret, env.ADMIN_SECRET));
}

async function handleAdminLogin(request: Request, env: Env): Promise<Response> {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, { status: 405 }, env);

  const configuredPassword = getAdminPassword(env);
  if (!configuredPassword || !getSessionSecret(env)) {
    return json({ error: 'Admin authentication is not configured.' }, { status: 500 }, env);
  }

  const body = (await request.json().catch(() => ({}))) as JsonRecord;
  const username = String(body.username || '').trim();
  const password = String(body.password || '');

  if (!safeEqual(username, getAdminUsername(env)) || !safeEqual(password, configuredPassword)) {
    return unauthorized(env);
  }

  const session = await createAdminToken(env, username);
  return json({ ok: true, authenticated: true, username, ...session }, {}, env);
}

async function handleAdminCollection(request: Request, env: Env, resource: Resource): Promise<Response> {
  if (!(await isAdmin(request, env))) return unauthorized(env);

  const table = TABLE_MAP[resource];
  const url = new URL(request.url);
  const id = url.pathname.split('/').filter(Boolean)[3];

  if (request.method === 'GET') {
    if (id) {
      const item = await first(env, `SELECT * FROM ${table} WHERE id = ? LIMIT 1`, [id]);
      return json({ item }, {}, env);
    }

    const limit = Math.min(200, Math.max(1, Number(url.searchParams.get('limit') || 100)));
    const offset = Math.max(0, Number(url.searchParams.get('offset') || 0));
    const where: string[] = [];
    const params: unknown[] = [];

    for (const key of ['category_id', 'sub_category_id', 'folder_id', 'media_type', 'source_type', 'is_active']) {
      const value = url.searchParams.get(key);
      if (!value) continue;
      if (key === 'is_active') {
        where.push(`${key} = ?`);
        params.push(value === 'true' || value === '1' ? 1 : 0);
      } else {
        where.push(`${key} = ?`);
        params.push(value);
      }
    }

    params.push(limit, offset);
    const sql = `
      SELECT * FROM ${table}
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY sort_order ASC, created_at DESC
      LIMIT ? OFFSET ?
    `;
    const items = await all(env, sql, params);
    return json({ items }, {}, env);
  }

  if (request.method === 'POST') {
    const body = cleanPayload(resource, (await request.json()) as JsonRecord);
    if (!body.id) body.id = crypto.randomUUID();
    if (!body.handle && body.title) body.handle = slugify(body.title);

    const keys = Object.keys(body).filter((key) => FIELD_MAP[resource].includes(key) || key === 'id');
    if (!keys.length) return badRequest('Empty payload.', env);

    const placeholders = keys.map(() => '?').join(', ');
    const values = keys.map((key) => body[key]);

    await run(env, `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`, values);
    const item = await first(env, `SELECT * FROM ${table} WHERE id = ? LIMIT 1`, [body.id]);
    return json({ item }, { status: 201 }, env);
  }

  if (!id) return badRequest('Missing id in URL.', env);

  if (request.method === 'PATCH') {
    const body = cleanPayload(resource, (await request.json()) as JsonRecord);
    const keys = Object.keys(body).filter((key) => FIELD_MAP[resource].includes(key));
    if (!keys.length) return badRequest('Empty payload.', env);

    const assignments = keys.map((key) => `${key} = ?`);
    assignments.push('updated_at = CURRENT_TIMESTAMP');
    const values = keys.map((key) => body[key]);
    values.push(id);

    await run(env, `UPDATE ${table} SET ${assignments.join(', ')} WHERE id = ?`, values);
    const item = await first(env, `SELECT * FROM ${table} WHERE id = ? LIMIT 1`, [id]);
    return json({ item }, {}, env);
  }

  if (request.method === 'DELETE') {
    await run(env, `DELETE FROM ${table} WHERE id = ?`, [id]);
    return json({ success: true }, {}, env);
  }

  return json({ error: 'Method not allowed' }, { status: 405 }, env);
}


export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(env) });
    }

    try {
      const url = new URL(request.url);
      const path = url.pathname.replace(/\/+$/, '') || '/';
      const parts = path.split('/').filter(Boolean);

      if (path === '/' || path === '/health') {
        return json({ ok: true, service: 'lexor-media-gallery-api', database: 'cloudflare-d1' }, {}, env);
      }

      if (path === '/api/gallery/tree' && request.method === 'GET') {
        return handleTree(request, env);
      }

      if (path === '/api/gallery/media' && request.method === 'GET') {
        return handleMedia(request, env);
      }

      if (path === '/api/admin/login') {
        return handleAdminLogin(request, env);
      }

      if (path === '/api/admin/verify' && request.method === 'GET') {
        if (!(await isAdmin(request, env))) return unauthorized(env);
        return json({ ok: true, authenticated: true }, {}, env);
      }

      if (parts[0] === 'api' && parts[1] === 'admin' && isResource(parts[2])) {
        return handleAdminCollection(request, env, parts[2]);
      }

      return notFound(env);
    } catch (error) {
      return json({
        error: 'Internal error',
        message: error instanceof Error ? error.message : String(error),
      }, { status: 500 }, env);
    }
  },
};
