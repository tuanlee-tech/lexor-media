-- Optional sample data for Lexor Media Gallery MVP on Cloudflare D1.
-- Apply after schema.sql.

INSERT OR IGNORE INTO categories (id, title, handle, sort_order, is_active)
VALUES
  ('cat_company', 'Company', 'company', 10, 1),
  ('cat_pedi_chair', 'Pedi-Chair', 'pedi-chair', 20, 1),
  ('cat_customers', 'Customers', 'customers', 30, 1);

INSERT OR IGNORE INTO sub_categories (id, category_id, title, handle, sort_order, is_active)
VALUES
  ('sub_about_lexor', 'cat_company', 'About LEXOR', 'about-lexor', 10, 1),
  ('sub_our_customer', 'cat_customers', 'Our Customer', 'our-customer', 10, 1);

INSERT OR IGNORE INTO folders (id, category_id, sub_category_id, title, handle, sort_order, is_active)
VALUES
  ('folder_venus_nails', 'cat_customers', 'sub_our_customer', 'Chủ tiệm Venus Nails', 'chu-tiem-venus-nails', 10, 1);

INSERT OR IGNORE INTO media_items (
  id,
  category_id,
  sub_category_id,
  folder_id,
  media_type,
  source_type,
  url,
  thumbnail_url,
  title,
  alt,
  sort_order,
  is_active
)
VALUES
  (
    'media_about_lexor_video',
    'cat_company',
    'sub_about_lexor',
    NULL,
    'video',
    'youtube',
    'https://www.youtube.com/watch?v=PijtXFav_ts',
    NULL,
    'About LEXOR — Tập 2: Đẳng Cấp Bắt Đầu Từ Dịch Vụ Chuyên Nghiệp',
    'About LEXOR video',
    10,
    1
  );
