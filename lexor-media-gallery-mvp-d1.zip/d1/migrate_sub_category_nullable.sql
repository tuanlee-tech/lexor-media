-- ============================================
-- Migration: Allow nullable sub_category_id in media_items
-- Run: npx wrangler d1 execute lexor-media-gallery-db --file=migrate_sub_category_nullable.sql --remote
-- ============================================

PRAGMA foreign_keys = OFF;

-- 1. Create new table with nullable sub_category_id
CREATE TABLE media_items_new (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  sub_category_id TEXT,
  folder_id TEXT,
  media_type TEXT NOT NULL CHECK(media_type IN ('image', 'video')),
  source_type TEXT NOT NULL DEFAULT 'shopify' CHECK(source_type IN ('shopify', 'youtube', 'external')),
  shopify_file_id TEXT,
  url TEXT NOT NULL,
  thumbnail_url TEXT,
  title TEXT NOT NULL,
  alt TEXT,
  description TEXT,
  width INTEGER,
  height INTEGER,
  duration REAL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
  FOREIGN KEY (sub_category_id) REFERENCES sub_categories(id) ON DELETE SET NULL,
  FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE SET NULL
);

-- 2. Migrate data
INSERT INTO media_items_new SELECT * FROM media_items;

-- 3. Drop old table
DROP TABLE media_items;

-- 4. Rename new table
ALTER TABLE media_items_new RENAME TO media_items;

-- 5. Recreate indexes
CREATE INDEX IF NOT EXISTS idx_media_scope_type_sort 
  ON media_items(category_id, sub_category_id, folder_id, media_type, is_active, sort_order, created_at);
CREATE INDEX IF NOT EXISTS idx_media_folder_type_sort 
  ON media_items(folder_id, media_type, is_active, sort_order, created_at);

PRAGMA foreign_keys = ON;