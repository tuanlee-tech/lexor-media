-- Cloudflare D1 schema for Lexor Media Gallery MVP.
-- Apply with: npx wrangler d1 execute lexor-media-gallery-db --file=../d1/schema.sql --local

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  handle TEXT NOT NULL UNIQUE,
  icon_svg TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sub_categories (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  title TEXT NOT NULL,
  handle TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
  UNIQUE(category_id, handle)
);

CREATE TABLE IF NOT EXISTS folders (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  sub_category_id TEXT NOT NULL,
  title TEXT NOT NULL,
  handle TEXT NOT NULL,
  description TEXT,
  cover_image_url TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
  FOREIGN KEY (sub_category_id) REFERENCES sub_categories(id) ON DELETE CASCADE,
  UNIQUE(sub_category_id, handle)
);

CREATE TABLE IF NOT EXISTS media_items (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  sub_category_id TEXT NOT NULL,
  folder_id TEXT,
  media_type TEXT NOT NULL CHECK(media_type IN ('image', 'video')),
  source_type TEXT NOT NULL DEFAULT 'shopify' CHECK(source_type IN ('shopify', 'youtube', 'external')),
  shopify_file_id TEXT,
  url TEXT NOT NULL,
  thumbnail_url TEXT,
  title TEXT NOT NULL,
  alt TEXT,
  description TEXT,
  width INTEGER,
  height INTEGER,
  duration REAL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
  FOREIGN KEY (sub_category_id) REFERENCES sub_categories(id) ON DELETE CASCADE,
  FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_categories_active_sort ON categories(is_active, sort_order, title);
CREATE INDEX IF NOT EXISTS idx_sub_categories_category_active_sort ON sub_categories(category_id, is_active, sort_order, title);
CREATE INDEX IF NOT EXISTS idx_folders_scope_active_sort ON folders(category_id, sub_category_id, is_active, sort_order, title);
CREATE INDEX IF NOT EXISTS idx_media_scope_type_sort ON media_items(category_id, sub_category_id, folder_id, media_type, is_active, sort_order, created_at);
CREATE INDEX IF NOT EXISTS idx_media_folder_type_sort ON media_items(folder_id, media_type, is_active, sort_order, created_at);
