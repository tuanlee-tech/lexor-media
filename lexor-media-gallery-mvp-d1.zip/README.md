# Lexor Media Gallery MVP — Cloudflare D1 version

MVP này thay thế cách nhập media bằng Shopify section block/textarea bằng một hệ thống tách riêng:

- **Shopify Files/CDN**: lưu ảnh/video thật.
- **Cloudflare D1**: lưu metadata, category, sub category, folder, sort order.
- **Cloudflare Worker Free**: API đọc/ghi data, dùng D1 binding.
- **Cloudflare Pages Free**: host Admin Dashboard và Widget JS/CSS.
- **Shopify section container**: nhúng widget vào `/pages/media`.

> Bản này là Step 1-D1: nền móng kỹ thuật + API + admin CRUD cơ bản + widget storefront cơ bản. Upload tự động vào Shopify Files sẽ làm ở bước sau.

---

## 1. Cấu trúc thư mục

```text
lexor-media-gallery-mvp-d1/
├─ d1/
│  ├─ schema.sql
│  └─ seed.sql
├─ worker/
│  ├─ src/index.ts
│  ├─ package.json
│  ├─ tsconfig.json
│  └─ wrangler.toml.example
├─ admin/
│  ├─ index.html
│  └─ assets/
│     ├─ admin.css
│     └─ admin.js
├─ widget/
│  ├─ lexor-media-gallery.js
│  └─ lexor-media-gallery.css
└─ shopify/
   └─ sections/
      └─ lexor-media-gallery-widget.liquid
```

---

## 2. Setup Cloudflare Worker + D1 local

Vào thư mục `worker`:

```bash
cd worker
npm install
cp wrangler.toml.example wrangler.toml
```

Tạo D1 database:

```bash
npx wrangler d1 create lexor-media-gallery-db
```

Sau khi chạy lệnh, Cloudflare sẽ trả về đoạn cấu hình `[[d1_databases]]`. Copy `database_id` đó vào `worker/wrangler.toml`.

Ví dụ:

```toml
[[d1_databases]]
binding = "DB"
database_name = "lexor-media-gallery-db"
database_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

Sửa thêm admin secret:

```toml
[vars]
ADMIN_SECRET = "mat-khau-admin-tu-dat"
CORS_ORIGIN = "*"
```

Apply schema local:

```bash
npx wrangler d1 execute lexor-media-gallery-db --file=../d1/schema.sql --local
```

Thêm data mẫu local:

```bash
npx wrangler d1 execute lexor-media-gallery-db --file=../d1/seed.sql --local
```

Chạy Worker local:

```bash
npm run dev
```

Test:

```text
http://localhost:8787/health
http://localhost:8787/api/gallery/tree
http://localhost:8787/api/gallery/media
```

---

## 3. Mở Admin Dashboard local

Mở file:

```text
admin/index.html
```

Trong tab Settings nhập:

```text
API Base URL: http://localhost:8787
Admin Secret: mat-khau-admin-tu-dat
```

Sau đó thử tạo:

```text
Category: Customers
Sub Category: Our Customer
Folder: Chủ tiệm Venus Nails
Media item: 1 ảnh hoặc 1 YouTube URL
```

---

## 4. Deploy D1 production

Khi local đã chạy ổn, apply schema lên D1 production:

```bash
cd worker
npx wrangler d1 execute lexor-media-gallery-db --file=../d1/schema.sql --remote
```

Seed production nếu cần data mẫu:

```bash
npx wrangler d1 execute lexor-media-gallery-db --file=../d1/seed.sql --remote
```

Deploy Worker:

```bash
npm run deploy
```

Worker URL sẽ có dạng:

```text
https://lexor-media-gallery-api.YOUR_SUBDOMAIN.workers.dev
```

Dùng URL đó làm API Base URL cho Admin Dashboard và Shopify section.

---

## 5. Shopify section container

Upload file này vào Shopify theme:

```text
shopify/sections/lexor-media-gallery-widget.liquid
```

Trong Theme Editor, add section `Lexor Media Gallery Widget`, sau đó điền:

```text
API Base URL: https://lexor-media-gallery-api.YOUR_SUBDOMAIN.workers.dev
Widget JS URL: URL của widget/lexor-media-gallery.js sau khi host lên Cloudflare Pages
Widget CSS URL: URL của widget/lexor-media-gallery.css sau khi host lên Cloudflare Pages
```

Trong giai đoạn local test, có thể chưa cần Shopify. Test API + Admin trước.

---

## 6. Ghi chú quan trọng

- D1 chỉ lưu metadata, không lưu ảnh/video binary.
- File thật vẫn nên lưu ở Shopify Files/CDN.
- `ADMIN_SECRET` chỉ dùng trong Admin Dashboard, không đưa vào storefront widget.
- Storefront API chỉ trả item có `is_active = true`.
- API có pagination, không render toàn bộ vài ngàn media cùng lúc.
